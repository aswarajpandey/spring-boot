### Relevant Articles: 
- [Logging in Spring Boot](http://www.baeldung.com/spring-boot-logging)
